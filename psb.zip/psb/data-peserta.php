<?php 
session_start();
include 'koneksi.php';
if($_SESSION['stat_login'] != true){
    echo '<script>window.location="login.php"</script>';
}

// Inisialisasi variabel default untuk filtering dan sorting
$keyword = "";
$sort = "id_pendaftaran";
$order = "DESC";

// Jika tombol Cari ditekan, atur variabel keyword
if(isset($_POST['bcari'])){
    $keyword = $_POST['tcari'];
}

// Jika terdapat parameter sort dan order, atur variabel sorting
if(isset($_GET['sort']) && isset($_GET['order'])){
    $sort = $_GET['sort'];
    $order = $_GET['order'];
}

// Buat query berdasarkan keyword dan pengurutan
$q ="SELECT * FROM tb_pendaftaran WHERE nm_peserta LIKE '%$keyword%' OR kelas LIKE '%$keyword%' ORDER BY $sort $order";

$list_peserta = mysqli_query($conn, $q);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>PSB ONLINE | ADMINISTRATOR</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@500&family=Roboto+Mono&display=swap" rel="stylesheet">
</head>
<body>
    
    <!-- bagian header -->
    <header>
        <h1><a href="beranda.php">Admin PSB</a></h1>
        <ul>
            <li><a href="beranda.php">Beranda</a></li>
            <li><a href=".data-peserta.php">Data Peserta</a></li>
            <li><a href="index.php">Pendaftaran</a></li>
            <li><a href="keluar.php">Keluar</a></li>
        </ul>
    </header>

    <!-- bagian content -->
    <section class="content">
        <h2>Data Peserta</h2>
        <div class="box">
            <a href="cetak-peserta.php" target="_blank" class="btn-cetak">Print</a>

            <form method="POST">
        <div class="input-group">
            <input type="text" name="tcari" class="from-control" placeholder="Masukan Nama/kelas !" value="<?php echo $keyword; ?>">
            <button class="btn btn-warning" name="bcari" type="submit">Cari</button>
            <button class="btn btn-danger" name="breset" type="submit">Reset</button>
        </div>
            </form>
            <table class="table" border="1">
                <thead>
                    <tr>
                        <th>No</th>
                        <th><a href="?sort=id_pendaftaran&order=<?php echo ($sort == 'id_pendaftaran' && $order == 'DESC') ? 'ASC' : 'DESC'; ?>">ID Pendaftaran</a></th>
                        <th><a href="?sort=nm_peserta&order=<?php echo ($sort == 'nm_peserta' && $order == 'DESC') ? 'ASC' : 'DESC'; ?>">Nama</a></th>
                        <th><a href="?sort=jk&order=<?php echo ($sort == 'jk' && $order == 'DESC') ? 'ASC' : 'DESC'; ?>">Jenis Kelamin</a></th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        $no = 1;
                        while($row = mysqli_fetch_array($list_peserta)){
                     ?>
                    <tr>
                        <td><?php echo $no++ ?></td>
                        <td><?php echo $row['id_pendaftaran'] ?></td>
                        <td><?php echo $row['nm_peserta'] ?></td>
                        <td><?php echo $row['jk'] ?></td>
                        <td>
                            <a href="detail-peserta.php?id=<?php echo $row['id_pendaftaran'] ?>">Detail</a> || 
                            <a href="hapus-peserta.php?id=<?php echo $row['id_pendaftaran'] ?>" onclick="return confirm('Yakin di hapus ?')">Hapus</a> ||
                            <a href="edit.php?id=<?php echo $row['id_pendaftaran'] ?>" onclick="return confirm('Yakin di edit ?')">Edit</a>
                        </td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </section>
</body>
</html>
