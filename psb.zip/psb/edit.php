<?php
include 'koneksi.php';

// Fungsi untuk mengambil data pendaftaran berdasarkan ID
function getPendaftaranByID($conn, $id) {
    $id_pendaftaran = mysqli_real_escape_string($conn, $id);
    $query = "SELECT * FROM tb_pendaftaran WHERE id_pendaftaran = '$id_pendaftaran'";
    $result = mysqli_query($conn, $query);
    return mysqli_fetch_assoc($result);
}

if (isset($_POST['Edit'])) {
    // Ambil ID pendaftaran yang akan diedit dari form
    $id_pendaftaran = $_POST['id_pendaftaran'];
    $th_ajaran = $_POST['th_ajaran'];
    $kelas = $_POST['kelas'];
    $nm_peserta = $_POST['nm'];
    $tmp_lahir = $_POST['tmp_lahir'];
    $tgl_lahir = $_POST['tgl_lahir'];
    $jk = $_POST['jk'];
    $agama = $_POST['agama'];
    $almt_peserta = $_POST['almt_peserta'];

    // Query untuk melakukan update data pendaftaran berdasarkan ID
    $query = "UPDATE tb_pendaftaran SET th_ajaran='$th_ajaran', kelas='$kelas', nm_peserta='$nm_peserta', tmp_lahir='$tmp_lahir', tgl_lahir='$tgl_lahir', jk='$jk', agama='$agama', almt_peserta='$almt_peserta' WHERE id_pendaftaran='$id_pendaftaran'";

    if (mysqli_query($conn, $query)) {
        echo '<script>alert("Data Berhasil DiEdit");</script>';
        echo '<script>window.location="data-peserta.php"</script>';
    } else {
        echo '<script>alert("Gagal mengedit data: ' . mysqli_error($conn) . '");</script>';
    }
}

// Ambil ID pendaftaran yang akan diedit dari URL
if (isset($_GET['id'])) {
    $id_pendaftaran = $_GET['id'];
    $data_pendaftaran = getPendaftaranByID($conn, $id_pendaftaran);

    // Periksa apakah ID yang diberikan valid
    if (!$data_pendaftaran) {
        echo '<script>alert("ID Pendaftaran tidak valid.");</script>';
        exit;
    }
} else {
    // Redirect atau tampilkan pesan kesalahan jika ID tidak diberikan
    echo '<script>alert("ID Pendaftaran tidak diberikan.");</script>';
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>PSB ONLINE</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@500&family=Roboto+Mono&display=swap" rel="stylesheet">
</head>
<body class="bg">
        
    <!-- bagian formulir box -->
    <section class="box-formulir">
        <h1>Edit Pendaftaran</h1>
        <!-- bagian form 1 -->
        <form action="" method="post">
            <input type="hidden" name="id_pendaftaran" value="<?php echo $id_pendaftaran; ?>">
            <div class="box">
                <table border="0" class="table-form">
                    <tr>
                        <td>Tahun Ajaran</td>
                        <td>:</td>
                        <td>
                            <input type="text" name="th_ajaran" class="input-control" value="<?php echo $data_pendaftaran['th_ajaran']; ?>" readonly>
                        </td>
                    </tr>
                    <tr>
                        <td>Jurusan</td>
                        <td>:</td>
                        <td>
                            <select class="input-control" name="kelas">
                                <option <?php if ($data_pendaftaran['kelas'] == 'KELAS A') { echo "selected"; } ?> value="KELAS A">KELAS A</option>
                                <option <?php if ($data_pendaftaran['kelas'] == 'KELAS B') { echo "selected"; } ?> value="KELAS B">KELAS B</option>
                            </select>
                        </td>
                    </tr>
                </table>
            </div>

            <!-- bagian form 2 -->
            <h3 class="H3">Data Diri Calon Siswa</h3>
            <div class="box">
                <table border="0" class="table-form">
                    <tr>
                        <td>Nama Lengkap</td>
                        <td>:</td>
                        <td>
                            <input type="text" name="nm" class="input-control" value="<?php echo $data_pendaftaran['nm_peserta']; ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>Tempat Lahir</td>
                        <td>:</td>
                        <td>
                            <input type="text" name="tmp_lahir" class="input-control" value="<?php echo $data_pendaftaran['tmp_lahir']; ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>Tanggal Lahir</td>
                        <td>:</td>
                        <td>
                            <input type="date" name="tgl_lahir" class="input-control" value="<?php echo $data_pendaftaran['tgl_lahir']; ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>Jenis Kelamin</td>
                        <td>:</td>
                        <td>
                            <select class="input-control" name="jk">
                                <option <?php if ($data_pendaftaran['jk'] == 'LAKI-LAKI') { echo "selected"; } ?> value="LAKI-LAKI">LAKI-LAKI</option>
                                <option <?php if ($data_pendaftaran['jk'] == 'PEREMPUAN') { echo "selected"; } ?> value="PEREMPUAN">PEREMPUAN</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Agama</td>
                        <td>:</td>
                        <td>
                            <select class="input-control" name="agama">
                                <option <?php if ($data_pendaftaran['agama'] == 'Islam') { echo "selected"; } ?> value="Islam">ISLAM</option>
                                <option <?php if ($data_pendaftaran['agama'] == 'Kristen') { echo "selected"; } ?> value="Kristen">KRISTEN</option>
                                <option <?php if ($data_pendaftaran['agama'] == 'Buddha') { echo "selected"; } ?> value="Buddha">BUDHA</option>
                                <option <?php if ($data_pendaftaran['agama'] == 'Hindu') { echo "selected"; } ?> value="Hindu">HINDU</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td>Alamat Lengkap</td>
                        <td>:</td>
                        <td>
                            <textarea class="input-control" name="almt_peserta"><?php echo $data_pendaftaran['almt_peserta']; ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td></td>
                        <td>
                            <input type="submit" name="Edit" class="btn-daftar" value="Edit">
                        </td>
                    </tr>
                </table>
            </div>
        </form>
    </section>
</body>
</html>