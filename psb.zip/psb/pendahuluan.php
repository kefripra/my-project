<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>PSB ONLINE | ADMINISTRATOR</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@500&family=Roboto+Mono&display=swap" rel="stylesheet">
    </head>
    <body>
        <div id="drum">
                <div class="container">
                  
                    <div class="content">   
                        <center>
                            <a href="login.php">
                                <img src="assets/student.png" alt="Login">
                                <h3>Login</h3>
                            </a>
                        </center>
                    </div>

                    <div class="content">
                        <center>
                            <a href="index.php">
                                <img src="assets/note.png" alt="Pendaftaran Siswa Baru">
                                <h3>Daftar</h3>
                            </a>
                        </center>
                    </div>  
                
                </div>
            </div>
    </body>
</html>