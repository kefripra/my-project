<?php 
	session_start();
	include 'koneksi.php';
	if($_SESSION['stat_login'] != true){
		echo '<script>window.location="login.php"</script>';
	}
 ?>
 
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>PSB ONLINE | ADMINISTRATOR</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@500&family=Roboto+Mono&display=swap" rel="stylesheet">
	</head>
<body class="bgg">
	
	<!-- bagian header -->
	<header>
		<h1><a href="beranda.php">Admin PSB</a></h1>
		<ul>
			<li><a href="beranda.php">Beranda</a></li>
			<li><a href="data-peserta.php">Data Peserta</a></li>
			<li><a href="index.php">Pendaftaran</a></li>
			<li><a href="keluar.php">Keluar</a></li>		
		</ul>
	</header>

	<!-- bagian content -->
	<section class="content">
		<div class="box">	
			<h1 class="beranda">SELAMAT DATANG DI PSB ONLINE</h3>

		</div>
	</section>

</body>
</html>